package model.Biglietteria;

public abstract class Biglietteria {

}
