package model.Mezzo;

public abstract class Mezzo {

}
