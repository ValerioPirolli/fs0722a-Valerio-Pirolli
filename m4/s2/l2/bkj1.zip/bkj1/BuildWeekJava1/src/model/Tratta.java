package model;

public class Tratta {

}
