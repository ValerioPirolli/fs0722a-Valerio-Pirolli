package model.Biglietteria;

public class RivenditoreAutomatico extends Biglietteria {

}
