package model.Ticket;

public class Biglietto extends Ticket {

}
