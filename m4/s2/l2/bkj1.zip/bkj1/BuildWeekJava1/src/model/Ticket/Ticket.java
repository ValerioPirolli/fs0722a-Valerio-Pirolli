package model.Ticket;

public abstract class Ticket {

}
