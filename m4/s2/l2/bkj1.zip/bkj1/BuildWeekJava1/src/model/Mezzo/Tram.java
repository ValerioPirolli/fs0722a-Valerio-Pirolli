package model.Mezzo;

public class Tram extends Mezzo {

}
