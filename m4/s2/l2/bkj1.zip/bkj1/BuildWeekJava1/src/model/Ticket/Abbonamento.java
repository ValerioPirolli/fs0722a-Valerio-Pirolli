package model.Ticket;

public class Abbonamento extends Ticket {

}
