package model.Mezzo;

public class Autobus extends Mezzo {

}
