package model.Biglietteria;

public class RivenditoreAutorizzato extends Biglietteria {

}
